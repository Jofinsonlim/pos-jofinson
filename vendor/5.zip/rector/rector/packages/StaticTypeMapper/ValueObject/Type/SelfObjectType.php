<?php

declare (strict_types=1);
namespace Rector\StaticTypeMapper\ValueObject\Type;

use PHPStan\Type\ObjectType;
final class SelfObjectType extends \PHPStan\Type\ObjectType
{
}
