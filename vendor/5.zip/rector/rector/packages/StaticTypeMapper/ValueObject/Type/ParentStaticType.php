<?php

declare (strict_types=1);
namespace Rector\StaticTypeMapper\ValueObject\Type;

use PHPStan\Type\StaticType;
final class ParentStaticType extends \PHPStan\Type\StaticType
{
}
